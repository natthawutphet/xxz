<?php
require "admin/db.php";

$stmt = $conn->query("SELECT * FROM weburl");
$stmt->execute();
$weburls = $stmt->fetchAll(); 

if (!$weburls){ 
}  else {
    foreach($weburls as $weburl)  { 
   $id = $weburl['id'];
   $weburls = $weburl['weburls'];
   $urllines = $weburl['urllines'];
   
    }
}
?>
  <html>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
  
    a {
        color: white; 
        text-decoration: none; 
    }
    
  
    a:hover {
        color: grey; 
    }
</style>
  
  <body>
  <div class="fixed-bottom">
  <div class="d-flex justify-content-center">
  <?php if(!empty($weburls)) { ?>
  
  <div class="text-bg-primary p-3 w-100 text-center">  <a href="web.php" target="_bank" >> > สมัครเลย < < </a></div>
  <?php } else {
 } ?>
     
  <?php if(!empty($urllines)) { ?>
    
    <div class="text-bg-success p-3 w-100 text-center">
    <a href="line.php" target="_bank" >> >  @Line < < </a></div>
   
    <?php } else {
 } ?>

      </div>
    </div>

  </body>
</html>







